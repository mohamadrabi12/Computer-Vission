import collections
import cv2
import numpy
from PIL import Image
import matplotlib.pyplot as plt

class DigitalImaging:
    
    def convert_to_gs(image_path):
        img_obj = Image.open(image_path)
        gray_img = img_obj.convert('L')
        return gray_img

    def color_at(img_arr,row_num,column_num):
        result = DigitalImaging.validate_coordinates(img_arr,row_num,column_num)
        if result == 3:
            r,g,b = img_arr[row_num][column_num]
            print("R,G,B at = ("+str(row_num)+","+str(column_num)+") = "+str(r)+","+str(g)+","+str(b))
            return r,g,b
        elif result == 1:
            grey = img_arr[row_num][column_num]
            print("Grey level = ",grey)
            return grey

   
    def reduce_to(image,char):
        img_obj = Image.open(image)
        img_arr = numpy.array(img_obj)
        if char.upper() == 'R':
            img_arr[:, :, (1,2)]=0
            return Image.fromarray(img_arr)
        if char.upper() == 'G':
            img_arr[:, :, (0,2)]=0
            return Image.fromarray(img_arr)
        if char.upper() == 'B':
            img_arr[:, :, (0,1)]=0
            return Image.fromarray(img_arr)

    def make_collage(img_arr):
        plt.rcParams["figure.figsize"] = [7.50, 3.50]
        plt.rcParams["figure.autolayout"] = True

        image = plt.imread(img_arr)
        titles = ['R', 'G', 'B']
        cmaps = [plt.cm.Reds_r, plt.cm.Greens_r, plt.cm.Blues_r]

        fig, axes = plt.subplots(1, 3)
        objs = zip(axes, (image, *image.transpose(2, 0, 1)), titles, cmaps)

        for ax, channel, title, cmap in objs:
            ax.imshow(channel, cmap=cmap)
            ax.set_title(title)
            ax.set_xticks(())
            ax.set_yticks(())

        plt.show()

    def shapes_dict(images_arr):
        d={}
        for img in images_arr:
            d[numpy.array(img).shape[0]]=numpy.array(img).shape
        d2=dict(collections.OrderedDict(sorted(d.items())))
        return d2

    def detect_obj(image, str):

     
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')
        
        img = cv2.imread(image)
        
        r = 500.0 / img.shape[1]
        dim = (500, int(img.shape[0] * r))
    
        resized = cv2.resize(img, dim, interpolation=cv2.INTER_AREA)

        grey = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)

        faces = face_cascade.detectMultiScale(grey, 1.3, 5)
        if (str == "face"):
            for (x, y, w, h) in faces:
                cv2.rectangle(resized, (x, y), (x + w, y + h), (255, 0, 0), 2)
                roi_grey = grey[y:y + h, x:x + w]
                roi_color = resized[y:y + h, x:x + w]
                eyes = eye_cascade.detectMultiScale(roi_grey)
        if (str == "eyes"):
            for (x, y, w, h) in faces:
                roi_grey = grey[y:y + h, x:x + w]
                roi_color = resized[y:y + h, x:x + w]
                eyes = eye_cascade.detectMultiScale(roi_grey)
            for (ex, ey, ew, eh) in eyes:
                cv2.rectangle(roi_color, (ex, ey), (ex + ew, ey + eh), (0, 255, 0), 2)

       
        cv2.imshow('', resized)
        cv2.waitKey(0)

    def detect_obj_adv(image, bool1, bool2):
        if (bool1 == True):
            if (bool2 == True):
                face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
                eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')
                img = cv2.imread(image)
                r = 500.0 / img.shape[1]
                dim = (500, int(img.shape[0] * r))
                resized = cv2.resize(img, dim, interpolation=cv2.INTER_AREA)
                grey = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)
                faces = face_cascade.detectMultiScale(grey, 1.3, 5)
                for (x, y, w, h) in faces:
                    cv2.rectangle(resized, (x, y), (x + w, y + h), (255, 0, 0), 2)
                    roi_grey = grey[y:y + h, x:x + w]
                    roi_color = resized[y:y + h, x:x + w]
                    eyes = eye_cascade.detectMultiScale(roi_grey)

                for (ex, ey, ew, eh) in eyes:
                    cv2.rectangle(roi_color, (ex, ey), (ex + ew, ey + eh), (0, 255, 0), 2)

                cv2.imshow('', resized)
                cv2.waitKey(0)
            else:
                DigitalImaging.detect_obj('', 'face')
        else:
            if (bool2 == True):
                DigitalImaging.detect_obj('', 'eyes')
            else:
                img = cv2.imread(image)
                r = 500.0 / img.shape[1]
                dim = (500, int(img.shape[0] * r))
                
                resized = cv2.resize(img, dim, interpolation=cv2.INTER_AREA)

                cv2.imshow('image', resized)
                cv2.waitKey(0)

    def detect_face_in_vid():
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        cap = cv2.VideoCapture(0)
        while True:
           
            _, img = cap.read()

            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

            faces = face_cascade.detectMultiScale(gray, 1.1, 4)

            for (x, y, w, h) in faces:
                cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)

            cv2.imshow('Video', img)

         
            k = cv2.waitKey(30) & 0xff
            if k == 27:
                break

        cap.release()




